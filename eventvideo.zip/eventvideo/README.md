# eventvideo

Query a short video from a match in wyscout event data.

This script is intended to provide assistance in data analysis conducted for the Soccer Analysis course of ETH Zurich.
Use for any other purpose is prohibited.

## Usage

1. Download and unzip the directory and navigate into it, then run

```bash
python eventvideo.py --help
```

An example usage for match with id `5541745` and match second `4479.73` would be

```bash
python eventvideo.py 5541745 4479.73 clip.mp4
```

If you are interested in the high quality video, just add `-hq` to the end:
```bash
python eventvideo.py 5541745 4479.73 clip.mp4 -hq
```

## Requirements

The Python (3.8 up to 3.12) script has been tested on Windows and Linux. It also works on some MacOS systems. No Python dependencies are required.